Jump-Kick – Firefox Tab Switcher
Copyright 2026 Gurpreet Luthra

This product includes software developed by Gurpreet Luthra.