<template>
  <ins
    class="adsbygoogle"
    style="display: block"
    data-ad-client="ca-pub-3734944050099256"
    data-ad-slot="4159195140"
    data-ad-format="auto"
    data-full-width-responsive="true"
  ></ins>
</template>

<script setup lang="js">
;(adsbygoogle = window.adsbygoogle || []).push({})
</script>
