# Backers

Thank you to everyone to support Fuse.js development. The amount of effort needed to maintain this and develop new features for the project is only made sustainable thanks to your generous financial backing.

You can join these backers by [sponsoring on GitHub](https://github.com/sponsors/krisk).

## 🥇 Gold Sponsor

- Be the first!

## 🥈 Silver Sponsor

- [Worksome](https://www.worksome.com/)
- [BairesDev](https://www.bairesdev.com/sponsoring-open-source-projects/)
- [LITSLINK](https://litslink.com/)

## 🥉 Bronze Sponsor

- Be the first!

## ☕ Standard

- [roboflow](https://roboflow.com/)
- [getsentry](https://sentry.io/welcome/)
